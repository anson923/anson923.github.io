﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using UnityEngine.UI;
using System;
using System.Text;
using System.Threading;
using System.IO;
using UnityEngine.SceneManagement;
using System.Security.Permissions;

public class Server : MonoBehaviour
{
    const int PORT_NO = 5002;
    const string SERVER_IP = "127.0.0.1";
    static IPAddress localAdd;
    static TcpListener listener;
    static TcpClient client;
    static NetworkStream nwStream;
    static StreamWriter sw;
    static StreamReader sr;
    public static bool isServer;
    public static bool updateTurn;
    public static bool showTurn;
    public static string playerForce;
    public static bool shot;
    public static bool showTurnClient;
    public static bool goal;
    public static bool lastTouch;
    public static bool updateSkillPos;
    static string lastTouchString;
    static bool clientDisconnected;
    public Button startServerBtn;
    public Button stopServerBtn;
    public Button clientBtn;
    public Button disconnectBtn;
    public Button mainMenuBtn;
    public Canvas lobby;
    public InputField networkIP;

    //public static Vector3 position;
    //public static Vector3 force;

    public static Thread SocketThread;

    List<GameObject> players;
    List<GameObject> enemies;
    GameObject gkp;
    GameObject gke;
    GameObject goalWallLeft;
    GameObject goalWallRight;
    GameObject soccer;
    

    TurnMenuOffline turnMenu;


    // Start is called before the first frame update
    void Start()
    {
        turnMenu = FindObjectOfType<TurnMenuOffline>().GetComponent<TurnMenuOffline>();
        UpdateObject();
        //If no server started
        if (listener == null)
        {
            startServerBtn.gameObject.SetActive(true);
            stopServerBtn.gameObject.SetActive(false);
            isServer = false;
            Debug.Log($"Server is now not exist.");

        }
        //If server is exist
        else
        {
            startServerBtn.gameObject.SetActive(false);
            stopServerBtn.gameObject.SetActive(true);
            isServer = true;
            Debug.Log($"Server is now existed!");
        }
        startServerBtn.onClick.AddListener(StartServer);
        stopServerBtn.onClick.AddListener(StopServer);
        disconnectBtn.onClick.AddListener(DisconnectServer);
        mainMenuBtn.onClick.AddListener(onMainMenu);
        lobby.gameObject.SetActive(true);
        clientDisconnected = false;
        localAdd = null;
        listener = null;
        client = null;
        nwStream = null;
        sw = null;
        sr = null;
        goal = false;
        showTurn = false;
        playerForce = null;
        updateTurn = false;
        lastTouch = false;
        lastTouchString = null;
        SocketThread = null;
        updateSkillPos = false;
        SocketThread = new Thread(ServerListen.Server);
        //position = Vector3.zero;
        AddObjectsList();
    }

    void AddObjectsList()
    {
        players = new List<GameObject>();
        enemies = new List<GameObject>();
        if (players.Count == 0 || players == null)
        {
            foreach (GameObject Object in GameObject.FindGameObjectsWithTag("Player"))
            {
                players.Add(Object);
            }
        }

        if (enemies.Count == 0 || enemies == null)
        {
            foreach (GameObject Object in GameObject.FindGameObjectsWithTag("Enemy"))
            {
                enemies.Add(Object);
            }
        }
        if (soccer == null)
        {
            soccer = GameObject.FindGameObjectWithTag("Ball");
        }

    }
    void UpdateObject()
    {
        if(gkp == null)
            gkp = GameObject.FindGameObjectWithTag("GoalKeeperPlayer");

        if (gke == null)
            gke = GameObject.FindGameObjectWithTag("GoalKeeperEnemy");

        if (goalWallLeft == null)
            goalWallLeft = GameObject.FindGameObjectWithTag("GoalLineLeft");

        if (goalWallRight == null)
            goalWallRight = GameObject.FindGameObjectWithTag("GoalLineRight");
        if (soccer == null)
            soccer = GameObject.FindGameObjectWithTag("Ball");
        
    }

    // Update is called once per frame
    void Update()
    {
        UpdateObject();
        

        if (soccer != null)
        {
            if (soccer.GetComponent<Rigidbody>().velocity.magnitude <= 1f)
            {
                soccer.GetComponent<Rigidbody>().velocity = Vector3.zero;
                soccer.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
            }
        }
        if (!isServer)
        {
            startServerBtn.gameObject.SetActive(true);
            stopServerBtn.gameObject.SetActive(false);
            clientBtn.gameObject.SetActive(true);
            isServer = false;
            Debug.Log($"GameServer - is not in use.");

        }
        else
        {
            startServerBtn.gameObject.SetActive(false);
            stopServerBtn.gameObject.SetActive(true);
            clientBtn.gameObject.SetActive(false);

        }
        if (client != null)
        {
            if (client.Connected)
            {

                if (updateSkillPos)
                {
                    updateSkillPos = false;
                    //Server update client(enemies) position. 
                    foreach (GameObject obj in enemies)
                    {
                        obj.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        obj.GetComponent<Transform>().localPosition = obj.GetComponent<SelectionOffline>().getOrigin;
                    }
                    PlayerPrefs.SetInt("RedCD", 5);
                }


                if (goal)
                {
                    goal = false;
                    foreach (GameObject Object in players)
                    {
                        Object.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        Object.GetComponent<Transform>().localPosition = Object.GetComponent<Player>().OriginalPosition;
                    }
                    foreach (GameObject Object in enemies)
                    {
                        Object.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        Object.GetComponent<Transform>().localPosition = Object.GetComponent<Player>().OriginalPosition;
                    }
                    soccer.GetComponent<Rigidbody>().velocity = Vector3.zero;
                    soccer.GetComponent<Transform>().localPosition = soccer.GetComponent<SoccerSpeedControlOffline>().OriginalPosition;
                    turnMenu.enabled = true;
                    StartCoroutine(turnMenu.YourturnMenu());
                }

                if (lastTouch)
                {
                    lastTouch = false;
                    string[] result = lastTouchString.Split(',');
                    string tag = result[1];
                    string name = result[2];
                    if (tag == "Player")
                    {
                        foreach (GameObject Object in players)
                        {
                            if (name == Object.name)
                                soccer.GetComponent<SoccerSpeedControlOffline>().lastTouch = Object;
                        }

                    }
                    else
                    {
                        foreach (GameObject Object in enemies)
                        {
                            if (name == Object.name)
                                soccer.GetComponent<SoccerSpeedControlOffline>().lastTouch = Object;
                        }
                    }
                }

                if (showTurnClient)
                {
                    showTurnClient = false;
                    StartCoroutine(turnMenu.YourturnMenu());
                }

                if (showTurn)
                {
                    showTurnMenu();
                }

                if (shot)
                {
                    UpdateShot();
                }

                if (updateTurn == true)
                {
                    updateTurn = false;
                    UpdateCurrentTurn();                  
                }

                //GoalKeeper enemy and player enable after connect.
                gkp.GetComponent<GoalKeeperOffline>().enabled = true;
                gke.GetComponent<GoalKeeperOffline>().enabled = true;
                GoalKeeperPositionUpdate();
                lobby.gameObject.SetActive(false);
                mainMenuBtn.gameObject.SetActive(false);
                turnMenu.enabled = true;
                if (disconnectBtn.GetComponentInChildren<Text>().text != "Close Server")
                {
                    disconnectBtn.GetComponentInChildren<Text>().text = "Close Server";
                }
                Debug.Log($"GameServer -  Listening to client message.");

                //TODO:Loop Update player position.

                foreach (GameObject Object in players)
                {
                    if (Object.GetComponent<Rigidbody>().velocity.magnitude > 0.1f)
                    {
                        Debug.Log($"Object speed is {Object.GetComponent<Rigidbody>().velocity.magnitude}");
                        string text = $"{Object.tag},{Object.name},vector3,{Object.GetComponent<Transform>().localPosition.x}" +
                        $",{Object.GetComponent<Transform>().localPosition.y}," +
                        $"{Object.GetComponent<Transform>().localPosition.z}";
                        Debug.Log($"GameServer - Sent: {text}");
                        sw.WriteLine(text);
                        sw.Flush();
                    }

                }

                foreach (GameObject Object in enemies)
                {
                    if (Object.GetComponent<Rigidbody>().velocity.magnitude > 0.1f)
                    {
                        Debug.Log($"Object speed is {Object.GetComponent<Rigidbody>().velocity.magnitude}");
                        string text = $"{Object.tag},{Object.name},vector3,{Object.GetComponent<Transform>().localPosition.x}" +
                        $",{Object.GetComponent<Transform>().localPosition.y}," +
                        $"{Object.GetComponent<Transform>().localPosition.z}";
                        Debug.Log($"GameServer - Sent: {text}");
                        sw.WriteLine(text);
                        sw.Flush();
                    }
                }
            }

            if (soccer.GetComponent<Rigidbody>().velocity.magnitude > 0.1f)
            {
                Debug.Log($"Object speed is {soccer.GetComponent<Rigidbody>().velocity.magnitude}");
                //Position
                string text = $"{soccer.tag},{soccer.name},vector3,{soccer.GetComponent<Transform>().localPosition.x}" +
                $",{soccer.GetComponent<Transform>().localPosition.y}," +
                $"{soccer.GetComponent<Transform>().localPosition.z}," +
                //Rotation
                $"{soccer.GetComponent<Transform>().localEulerAngles.x}," +
                $"{soccer.GetComponent<Transform>().localEulerAngles.y},{soccer.GetComponent<Transform>().localEulerAngles.z}";
                Debug.Log($"GameServer - Sent: {text}");
                sw.WriteLine(text);
                sw.Flush();
            }

            if (playerForce != null)
            {
                string[] result = playerForce.Split(',');
                string tag = result[0];
                string name = result[1];
                Vector3 force = new Vector3(float.Parse(result[3]), float.Parse(result[4]), float.Parse(result[5]));
                if (tag == "Player")
                {
                    foreach (GameObject Object in players)
                    {
                        if (name == Object.name)
                        {
                            Object.GetComponent<Rigidbody>().AddForce(force, ForceMode.Force);
                            playerForce = null;
                            break;
                        }
                    }
                }
                else
                {
                    foreach (GameObject Object in enemies)
                    {
                        if (name == Object.name)
                        {
                            Object.GetComponent<Rigidbody>().AddForce(force, ForceMode.Force);
                            playerForce = null;
                            break;
                        }
                    }

                }
            }

        }

        if (clientDisconnected == true)
        {
            listener.Stop();
            nwStream.Close();
            nwStream.Dispose();
            sw.Close();
            sw.Dispose();
            sr.Close();
            sr.Dispose();
            StopServer();
            clientDisconnected = false;
            localAdd = null;
            listener = null;
            client = null;
            isServer = false;
            SceneManager.LoadScene("Disconnected");
        }

    }

    private void GoalKeeperPositionUpdate()
    {
        try
        {
            Debug.Log($"Object speed is {gkp.GetComponent<Rigidbody>().velocity.magnitude}");
            string text = $"goalkeeper,{gkp.tag},{gkp.name},{gkp.GetComponent<Transform>().localPosition.x}" +
            $",{gkp.GetComponent<Transform>().localPosition.y}," +
            $"{gkp.GetComponent<Transform>().localPosition.z}," + $"{gke.GetComponent<Transform>().localPosition.x}," +
            $"{gke.GetComponent<Transform>().localPosition.y},{gke.GetComponent<Transform>().localPosition.z}";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (SocketException se)
        {
            Debug.Log($"Something Error : {se}");
            clientDisconnected = true;
        }
        catch(Exception ex)
        {
            Debug.Log($"Something Error : {ex}");
            clientDisconnected = true;
        }
    }

    private void OnDestroy()
    {
        if (isServer)
        {
            listener.Stop();
            nwStream.Close();
            nwStream.Dispose();
            sw.Close();
            sw.Dispose();
            sr.Close();
            sr.Dispose();
            StopServer();
            clientDisconnected = false;
            localAdd = null;
            listener = null;
            client = null;
            nwStream = null;
            sw = null;
            sr = null;
            goal = false;
            showTurn = false;
            playerForce = null;
            updateTurn = false;
            lastTouch = false;
            lastTouchString = null;

        }
    }

    public void StartServer()
    {
        SocketThread.Start();
    }

    //Other Thread.
    public static void ConntectedToServer()
    {
        if (client.Connected)
        {
            updateTurn = true;
            Debug.Log($"GameServer -  Client is now connected to the server from {client.Client.RemoteEndPoint}");
            //---incoming client connected---
            try
            {
                while (client.Connected)
                {
                    Debug.Log($"GameServer -  A client is connecting to the server.");
                    //---get the incoming data through a network stream---
                    nwStream = client.GetStream();
                    //byte[] buffer = new byte[client.ReceiveBufferSize];
                    sr = new StreamReader(nwStream);
                    sw = new StreamWriter(nwStream);
                    //---read incoming stream---
                    //int bytesRead = nwStream.Read(buffer, 0, client.ReceiveBufferSize);
                    object line = null;
                    //string line;

                    while ((line = sr.ReadLine()) != null)
                    {
                        Debug.Log($"GameServer -  A client is connecting to the server.(ReadLine)");
                        //---convert the data received into a string---
                        //string dataReceived = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                        Debug.Log("GameServer - Received : " + line);

                        //Demo of Collect Vector3.
                        if (line.ToString().Contains("vector3:"))
                        {
                            ////return object Parse To Vector3
                            //Vector3 result = ParseToVector3(line);
                            //Debug.Log($"GameServer - Received a Vector3 : X:{result.x}, Y:{result.y}, Z:{result.z} from Client!.");
                            //position = result;

                        }
                        if (line.ToString() == "Client Disconnected")
                        {
                            string clientIP = client.Client.RemoteEndPoint.AddressFamily.ToString();

                            Debug.Log($"GameServer - Client from {clientIP} is disconnecting to the server");
                            client.GetStream().Close();
                            client.Close();
                            Debug.Log($"GameServer - Client from {clientIP} is disconnected to the server");
                            // Client disconnected
                            clientDisconnected = true;
                            return;
                        }

                        //SEND MESSAGE FROM SERVER
                        if (line.ToString() == "Server Turn")
                        {
                            string text = "FromServer";
                            Debug.Log($"Sent: {text}");
                            sw.WriteLine(text);
                            sw.Flush();
                        }
                        // Detect if client disconnected
                        if (client.Client.Poll(0, SelectMode.SelectRead))
                        {
                            byte[] buff = new byte[1];
                            if (client.Client.Receive(buff, SocketFlags.Peek) == 0)
                            {
                                // Client disconnected
                                clientDisconnected = true;
                            }
                        }

                        if (line.ToString().Contains("CurrentTurn"))
                        {
                            string results = line.ToString();
                            string[] result = results.Split(',');
                            TurnMenuOffline.currentTurn = int.Parse(result[1]);
                            Debug.Log($"GameClient - Updated CurrentTurn TO {result[1]}");
                            showTurnClient = true;
                        }

                        if (line.ToString().Contains("Force"))
                        {
                            string result = line.ToString();
                            playerForce = result;
                        }

                        if (line.ToString() == "Shot")
                        {
                            string result = line.ToString();
                            bool temp = bool.Parse(result);
                            shot = temp;
                        }

                        if (line.ToString().Contains("showTurn"))
                        {
                            showTurnClient = true;
                        }

                        if (line.ToString().Contains("lastTouch"))
                        {
                            lastTouch = true;
                            lastTouchString = line.ToString();
                        }

                        if (line.ToString().Contains("updateSkillPos"))
                        {
                            updateSkillPos = true;
                        }

                        if (listener == null)
                        {
                            StopServer();
                            break;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Debug.Log($"Something is wrong: {ex}");
                clientDisconnected = true;
            }
        }

    }
    private void OnApplicationQuit()
    {
        if (isServer)
        {
            listener.Stop();
            nwStream.Close();
            nwStream.Dispose();
            sw.Close();
            sw.Dispose();
            sr.Close();
            sr.Dispose();
            StopServer();
            clientDisconnected = false;
            localAdd = null;
            listener = null;
            client = null;
            isServer = false;
        }
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }
        }
        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    //Other Thread.
    public static class ServerListen

    {

        public static void Server()

        {
            try
            {
                localAdd = null;
                listener = null;
                client = null;
                nwStream = null;
                sw = null;
                sr = null;
                
                localAdd = IPAddress.Parse(SERVER_IP);

                listener = new TcpListener(IPAddress.Any,PORT_NO);

                listener.Start();

                Debug.Log($"GameServer -  is now running at ip {localAdd} at port {PORT_NO}.");
                isServer = true;

                client = listener.AcceptTcpClient();

                ConntectedToServer();

            }
            catch (SocketException ex)
            {
                Debug.Log($"GameServer -  is now already in use at ip {localAdd} at port {PORT_NO}.");
            }


        }

    }
    public static void StopServer()
    {
        if (listener == null)
            return;


        listener.Stop();
        listener = null;
        localAdd = null;
        client = null;
        isServer = false;

    }

    public static void UpdateSkillPos()
    {
        try
        {
            Debug.Log($"GameServer - Now Updating skill position");
            string text = $"updateSkillPos,true";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
    }

    public static void UpdateCurrentTurn()
    {
        try
        {
            Debug.Log($"GameServer - Now Updating the current turn to {TurnMenuOffline.currentTurn}");
            int currentTurn = TurnMenuOffline.currentTurn;
            string text = $"CurrentTurn,{currentTurn}";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch(Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
    }

    public static void UpdateShot()
    {
        try
        {
            Debug.Log($"GameServer - Now Updating Shot to {shot}");
            bool Shot = shot;
            string text = $"Shot,{Shot}";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
       
    }

    public static void showTurnMenu()
    {
        try
        {
            Debug.Log($"GameServer - Now Updating showTurn to {showTurn}");
            bool ShowTurn = showTurn;
            showTurn = false;
            string text = $"showTurn,{ShowTurn}";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
        
    }

    public static void UpdateLastTouch(GameObject gameObject)
    {
        try
        {
            Debug.Log($"GameServer - Now Updating lastTouch to {gameObject}");
            string tag = gameObject.tag;
            string name = gameObject.name;
            string text = $"lastTouch,{tag},{name}";
            Debug.Log($"GameServer - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
    }


    private static Vector3 ParseToVector3(object pObject)
    {
        /**
        *Everytime is received an object is vector3.
        *It will have a vector3: before xyz. 
        *Therefore, vector3: start from 0 
        *and it is 8 character --> Remove(0,8)
        **/
        string temp = pObject.ToString().Remove(0, 8);
        string[] results = temp.Split(',');
        Vector3 finish = new Vector3(float.Parse(results[0]), float.Parse(results[1]), float.Parse(results[2]));
        return finish;
    }

    public void onMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }

    public void DisconnectServer()
    {
        if (isServer)
        {
            try
            {
                string text = $"Server Close";
                sw.WriteLine(text);
                sw.Flush();
                Debug.Log($"GameServer - Sent: {text}");
            }
            catch(SocketException se)
            {
                Debug.Log($"Something Error : {se}");
                clientDisconnected = true;
            }
            catch(Exception ex)
            {
                Debug.Log($"Something Error : {ex}");
            }
            
        }
    }

}
