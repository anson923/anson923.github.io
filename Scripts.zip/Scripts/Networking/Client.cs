﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Permissions;
using System.Threading;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Client : MonoBehaviour
{
    public Button clientBtn;
    public Button clientCloseBtn;
    public Button mainMenuBtn;
    public Canvas lobby;
    const int PORT_NO = 5003;
    const string SERVER_IP = "127.0.0.1";
    static string IP;
    static TcpClient client;
    static NetworkStream nwStream;
    static StreamWriter sw;
    static StreamReader sr;
    List<GameObject> players;
    List<GameObject> enemies;
    static List<string> UpdatePosList;
    public static GameObject tempForcePlayer;
    public static Vector3 tempForce;
    GameObject gkp ;
    GameObject gke;
    GameObject soccer;
    GameObject goalWallLeft;
    GameObject goalWallRight;
    static bool updateTurn;
    static bool showTurnClient;
    static bool updateGK;
    public static bool showTurnServer;
    public static bool goal;
    public static bool lastTouch;
    public static bool updateSkillPos;
    static string lastTouchString;
    static int currentTurn;
    static bool finished;
    static string gkString;
    string oldgkString;
    public InputField networkIP;


    TurnMenuOffline turnMenu;

    public static Thread SocketThread;

    //public static Vector3 position;
    //public static Vector3 force;

    //public static string name;
    //public static string tag;

    // Start is called before the first frame update
    void Start()
    {
        turnMenu = FindObjectOfType<TurnMenuOffline>().GetComponent<TurnMenuOffline>();
        clientCloseBtn.gameObject.SetActive(false);
        clientBtn.onClick.AddListener(clientConnect);
        clientCloseBtn.onClick.AddListener(onClientClose);
        mainMenuBtn.onClick.AddListener(onMainMenu);
        UpdateObject();
        client = null;
        nwStream = null;
        sw = null;
        sr = null;
        IP = null;
        showTurnClient = false;
        showTurnServer = false;
        updateTurn = false;
        goal = false;
        currentTurn = 0;
        lastTouch = false;
        lastTouchString = null;
        finished = false;
        updateSkillPos = false;
        //force = Vector3.zero;
        AddObjectsList();

        tempForce = Vector3.zero;
        tempForcePlayer = null;
        SocketThread = null;
        SocketThread = new Thread(ClientConnect.ClientConnectServer);
    }

    void AddObjectsList()
    {
        players = new List<GameObject>();
        enemies = new List<GameObject>();
        UpdatePosList = new List<string>();
        if (players.Count == 0 || players == null)
        {
            foreach (GameObject Object in GameObject.FindGameObjectsWithTag("Player"))
            {
                players.Add(Object);
            }
        }

        if (enemies.Count == 0 || enemies == null)
        {
            foreach (GameObject Object in GameObject.FindGameObjectsWithTag("Enemy"))
            {
                enemies.Add(Object);
            }
        }

        if (soccer == null)
        {
            soccer = GameObject.FindGameObjectWithTag("Ball");
        }

    }

    void UpdateObject()
    {
        if (gkp == null)
            gkp = GameObject.FindGameObjectWithTag("GoalKeeperPlayer");

        if (gke == null)
            gke = GameObject.FindGameObjectWithTag("GoalKeeperEnemy");

        if (goalWallLeft == null)
            goalWallLeft = GameObject.FindGameObjectWithTag("GoalLineLeft");

        if (goalWallRight == null)
            goalWallRight = GameObject.FindGameObjectWithTag("GoalLineRight");

        if (soccer == null)
            soccer = GameObject.FindGameObjectWithTag("Ball");

    }

    // Update is called once per frame
    void Update()
    {
        UpdateObject();
        if (finished)
        {
            try
            {

                onClientClose();
            }
            catch (Exception ex)
            {
                Debug.Log($"Something wrong: {ex}");
            }

            Debug.Log($"Client Closed!");
        }
        if (soccer != null)
        {
            if(soccer.GetComponent<Rigidbody>().velocity.magnitude <= 1f)
            {
                soccer.GetComponent<Rigidbody>().velocity = Vector3.zero;
                soccer.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
            }
        }
        //if(position != player.GetComponent<Transform>().localPosition && Server.serverIsRunning == false)
        //{
        //    player.GetComponent<Transform>().localPosition = position;
        //}
        //If the client is assigned
        if (client != null)
        {
            //If the client is connected to the server successfully
            if(client.Connected == true)
            {
                if(updateSkillPos)
                {
                    //Client update server(players) position.
                    updateSkillPos = false;
                    foreach (GameObject obj in players)
                    {
                        obj.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        obj.GetComponent<Transform>().localPosition = obj.GetComponent<SelectionOffline>().getOrigin;
                    }
                    PlayerPrefs.SetInt("BlueCD", 5);
                }

                if (lastTouch)
                {
                    lastTouch = false;
                    string[] result = lastTouchString.Split(',');
                    string tag = result[1];
                    string name = result[2];
                    if(tag == "Player")
                    {
                        foreach (GameObject Object in players)
                        {
                            if (name == Object.name)
                                soccer.GetComponent<SoccerSpeedControlOffline>().lastTouch = Object;
                        }

                    }
                    else
                    {
                        foreach (GameObject Object in enemies)
                        {
                            if (name == Object.name)
                                soccer.GetComponent<SoccerSpeedControlOffline>().lastTouch = Object;
                        }
                    }
                }
                if (goal)
                {
                    goal = false;
                    foreach (GameObject Object in players)
                    {
                        Object.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        Object.GetComponent<Transform>().localPosition = Object.GetComponent<Player>().OriginalPosition;
                    }
                    foreach (GameObject Object in enemies)
                    {
                        Object.GetComponent<Rigidbody>().velocity = Vector3.zero;
                        Object.GetComponent<Transform>().localPosition = Object.GetComponent<Player>().OriginalPosition;
                    }
                    soccer.GetComponent<Rigidbody>().velocity = Vector3.zero;
                    soccer.GetComponent<Transform>().localPosition = soccer.GetComponent<SoccerSpeedControlOffline>().OriginalPosition;

                    turnMenu.enabled = true;
                    StartCoroutine(turnMenu.YourturnMenu());
                }

                if (showTurnClient)
                {
                    showTurnClient = false;
                    StartCoroutine(turnMenu.YourturnMenu());
                }
                if(showTurnServer)
                {
                    showTurnMenu();
                }
                if(updateTurn)
                {
                    updateTurn = false;
                    TurnMenuOffline.currentTurn = currentTurn;
                    Debug.Log($"GameClient - Updated CurrentTurn TO {TurnMenuOffline.currentTurn}");
                    StartCoroutine(turnMenu.YourturnMenu());
                }

                //GoalKeeper enemy and player enable after connect.
                gkp.GetComponent<GoalKeeperOffline>().enabled = true;
                gke.GetComponent<GoalKeeperOffline>().enabled = true;
                clientCloseBtn.gameObject.SetActive(true);
                clientBtn.gameObject.SetActive(false);
                lobby.gameObject.SetActive(false);
                mainMenuBtn.gameObject.SetActive(false);
                turnMenu.enabled = true;

                if(updateGK)
                {
                    if(oldgkString != gkString)
                    {
                        oldgkString = gkString;
                        UpdateGoalKeeperPosition(oldgkString);
                    }
                    
                }

                if (UpdatePosList.Count > 0)
                {
                    try
                    {
                        for(int i = 0; i < UpdatePosList.Count;i++)
                        {
                            string code = UpdatePosList[0];
                            string[] results = code.Split(',');
                            Vector3 position = new Vector3(float.Parse(results[3]), float.Parse(results[4]), float.Parse(results[5]));
                            string name = results[1];
                            string tag = results[0];
                            if (tag == "Player")
                            {
                                foreach (GameObject Object in players)
                                {
                                    if (name == Object.name)
                                    {
                                        Object.GetComponent<Player>().UpdatePosition(position);
                                        UpdatePosList.RemoveAt(0);
                                        break;
                                    }
                                }
                            }
                            else if(tag == "Enemy")
                            {
                                foreach (GameObject Object in enemies)
                                {
                                    if (name == Object.name)
                                    {
                                        Object.GetComponent<Player>().UpdatePosition(position);
                                        UpdatePosList.RemoveAt(0);
                                        break;
                                    }
                                }
                            }
                            else if(tag == "Ball")
                            {
                                if(name == soccer.name)
                                {
                                    Vector3 rotation = new Vector3(float.Parse(results[6]), float.Parse(results[7]), float.Parse(results[8]));
                                    Debug.Log($"GameClient - Soccer Received Rotation {rotation}");
                                    soccer.GetComponent<Transform>().localPosition = position;
                                    soccer.GetComponent<Transform>().localEulerAngles = rotation;
                                    UpdatePosList.RemoveAt(0);
                                    break;
                                }
                            }
                            #region GoalKeeperUpdates
                            //else
                            //{
                            //    if (name == gkp.name)
                            //    {
                            //        gkp.GetComponent<Transform>().localPosition = position;
                            //        UpdatePosList.RemoveAt(0);
                            //        break;
                            //    }
                            //    else if(name == gke.name)
                            //    {
                            //        gke.GetComponent<Transform>().localPosition = position;
                            //        UpdatePosList.RemoveAt(0);
                            //        break;
                            //    }

                            //}
                            #endregion
                        }
                    }
                    catch(Exception ex)
                    {
                        Debug.Log($"Error shown up from UpdatePosList: {ex}");
                    }
                }

                
            }
            //If the client not connecting any server.
            else
            {
                clientCloseBtn.gameObject.SetActive(false);
                clientBtn.gameObject.SetActive(true);
            }
        }


        if(tempForce != Vector3.zero && tempForcePlayer != null)
        {
            AddForce(tempForcePlayer, tempForce);
        }
    }

    public static string GetLocalIPAddress()
    {
        var host = Dns.GetHostEntry(Dns.GetHostName());
        foreach (var ip in host.AddressList)
        {
            if (ip.AddressFamily == AddressFamily.InterNetwork)
            {
                return ip.ToString();
            }
        }
        throw new Exception("No network adapters with an IPv4 address in the system!");
    }

    void clientConnect()
    {
        try
        {

            //---create a TCPClient object at the IP and port no.---
            
            client = null;
            nwStream = null;
            if(networkIP.text == null || networkIP.text == "" || IP.ToLower() == "localhost")
            {
                IP = "127.0.0.1";
            }
            else
            {
                IP = networkIP.text;
            }
            //if (IP == "127.0.0.1" || IP.ToLower() == "localhost")
            //{
            //    IP = GetLocalIPAddress();
            //}

            SocketThread.Start();

        }
        catch(Exception ex)
        {
            //Server not avaliable.
            Debug.Log($"Something Error : {ex}");
        }
        
    }

    private void OnDestroy()
    {
        try
        {
            client = null;
            nwStream = null;
            sw = null;
            showTurnClient = false;
            showTurnServer = false;
            updateTurn = false;
            goal = false;
            currentTurn = 0;
            lastTouch = false;
            lastTouchString = null;
            finished = false;
            tempForce = Vector3.zero;
            tempForcePlayer = null;
            Debug.Log("Scene Destroyed!");
        }
        catch(Exception ex)
        {
            Debug.Log($"Something Error : {ex}");
        }
    }

    private void OnApplicationQuit()
    {
        try
        {
            client = null;
            nwStream = null;
            sw = null;
            showTurnClient = false;
            showTurnServer = false;
            updateTurn = false;
            goal = false;
            currentTurn = 0;
            lastTouch = false;
            lastTouchString = null;
            finished = false;
            tempForce = Vector3.zero;
            tempForcePlayer = null;
            Debug.Log("onApplicationQuit!");
        }
        catch (Exception ex)
        {
            Debug.Log($"Something Error : {ex}");
        }
    }



    public static class ClientConnect
    {
        public static void ClientConnectServer()
        {
            try
            {
                Debug.Log($"Connecting to the server: {IP},{PORT_NO} ");
                client = new TcpClient(IP, PORT_NO);
                Debug.Log($"Connected to the server: {IP},{PORT_NO} ");
                nwStream = client.GetStream();
                sw = new StreamWriter(nwStream);
                sr = new StreamReader(nwStream);
                //---send the text---
                string text = "";

                //Vector3 apple = new Vector3(0.1f, 0.2f, 0.3f);
                //string send = $"vector3:{apple.x},{apple.y},{apple.z}";
                string send = "Hello server!";
                sw.WriteLine(send);
                sw.Flush();


                //text = "Server Turn";
                //sw.WriteLine(text);
                //sw.Flush();

                
                while (client.Connected)
                {
                    Debug.Log($"GameClient - Connecting to the server");
                    //---get the incoming data through a network stream---
                    //nwStream = client.GetStream();
                    //byte[] buffer = new byte[client.ReceiveBufferSize];
                    //sr = new StreamReader(nwStream);
                    //---read incoming stream---
                    //int bytesRead = nwStream.Read(buffer, 0, client.ReceiveBufferSize);
                    string line = null;

                    
                    while ((line = sr.ReadLine()) != null)
                    {
                        Debug.Log($"GameClient - Connecting to the server(ReadLine)");
                        #region Example
                        //---convert the data received into a string---
                        //string dataReceived = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                        //Debug.Log("GameServer - Received : " + line);

                        //GET MESSAGE FROM SERVER
                        //if (line == "FromServer")
                        //{
                        //    Debug.Log($"Received: {line}");
                        //    text = "Client Disconnected";
                        //    sw.WriteLine(text);
                        //    sw.Flush();
                        //    client.Client.Disconnect(false);
                        //    client.Close();
                        //    return;
                        //}
                        #endregion

                        if (line.Contains("goalkeeper"))
                        {
                            updateGK = true;
                            gkString = line;

                        }

                        if (line.Contains("vector3"))
                        {
                            //return object Parse To Vector3
                            ParseToVector3(line);
                        }

                        if(line.Contains("CurrentTurn"))
                        {

                            updateTurn = true;
                            string[] temp = line.Split(',');
                            currentTurn = int.Parse(temp[1]);
                        }
                        if(line == "Server Close")
                        {
                            if(!Server.isServer)
                            {
                                Debug.Log($"Received Server Close!");
                                string text1 = "Client Disconnected";
                                sw.WriteLine(text1);
                                sw.Flush();
                                client.Close();
                                finished = true;
                            }
                            
                        }

                        //if(line == "NewTurn")
                        //{
                        //    updateTurn = true;
                        //}

                        if(line == "Shot")
                        {
                            string result = line;
                            bool temp = bool.Parse(result);
                            Server.shot = temp;
                        }

                        if(line.Contains("showTurn"))
                        {
                            showTurnClient = true;
                        }

                        if(line.Contains("lastTouch"))
                        {
                            lastTouch = true;
                            lastTouchString = line;
                        }

                        if(line.Contains("updateSkillPos"))
                        {
                            updateSkillPos = true;
                        }

                        if (client == null)
                        {
                            break;
                        }

                    }
                    
                }

            }
            catch(Exception ex)
            {
                //Debug.
                Debug.Log($"Something Error : {ex}");
            }
        }
    }



    public void onClientClose()
    {
        if(!Server.isServer)
        {
            try
            {
                string text = "Client Disconnected";
                sw.WriteLine(text);
                sw.Flush();
                nwStream.Close();
                nwStream.Dispose();
                sw.Close();
                sw.Dispose();
                sr.Close();
                sr.Dispose();
                client.Close();
                client = null;
                SceneManager.LoadScene("Disconnected");
            }
            catch(Exception ex)
            {
                Debug.Log($"Something Error : {ex}");
                SceneManager.LoadScene("Disconnected");
            }
            
        }
        
    }

    public void UpdateGoalKeeperPosition(string pResult)
    {
        string[] result = pResult.Split(',');
        Vector3 gkpPosition = new Vector3(float.Parse(result[3]), float.Parse(result[4]), float.Parse(result[5]));
        Vector3 gkePosition = new Vector3(float.Parse(result[6]), float.Parse(result[7]), float.Parse(result[8]));
        try
        {
            gkp.GetComponent<Transform>().localPosition = gkpPosition;
            gke.GetComponent<Transform>().localPosition = gkePosition;
            Debug.Log($"GameClient - GoalKeeper Position Updating!");
        }
        catch (Exception ex)
        {
            Debug.Log($"Something wrong: {ex}");
        }
    }

    private static void ParseToVector3(string pObject)
    {
        /**
        *Everytime is received an object is vector3.
        *It will have a vector3: before xyz. 
        *Therefore, vector3: start from 0 
        *and it is 8 character --> Remove(0,8)
        **/
        string[] results = pObject.Split(',');
        Vector3 finish = new Vector3(float.Parse(results[3]), float.Parse(results[4]), float.Parse(results[5]));
        Debug.Log($"GameClient - Received PlayerType: {results[0]}, PlayerName: {results[1]}, Force: {finish}");
        try
        {
            //If position doesn't change, ignore it.
            if(!UpdatePosList.Contains(pObject))
            {
                UpdatePosList.Add(pObject);

                Debug.Log($"GameClient - Added Player!");
            }
            
        }
        catch(Exception ex)
        {
            Debug.Log($"GameClient - Something wrong in Lists: {ex}");
        }
        
        //force = finish;
    }


    public static void UpdateCurrentTurn()
    {
        try
        {
            int currentTurn = TurnMenuOffline.currentTurn;
            string text = $"CurrentTurn,{currentTurn}";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
            return;
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
    }

    public static void UpdateShot()
    {
        try
        {
            Debug.Log($"GameClient - Now Updating Shot to {Server.shot}");
            bool Shot = Server.shot;
            string text = $"Shot,{Shot}";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
        
    }

    public static void showTurnMenu()
    {
        try
        {
            Debug.Log($"GameClient - Now Updating showTurn to {showTurnServer}");
            bool ShowTurn = showTurnServer;
            showTurnServer = false;
            string text = $"showTurn,{ShowTurn}";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }


    }

    public static void UpdateLastTouch(GameObject gameObject)
    {
        try
        {
            Debug.Log($"GameClient - Now Updating lastTouch to {gameObject}");
            string tag = gameObject.tag;
            string name = gameObject.name;
            string text = $"lastTouch,{tag},{name}";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }

    }

    public static void UpdateSkillPos()
    {
        try
        {
            Debug.Log($"GameClient - Now Updating skill position");
            string text = $"updateSkillPos,true";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }
    }

    public void AddForce(GameObject Object, Vector3 force)
    {
        try
        {
            string text = $"{Object.tag},{Object.name},Force,{force.x},{force.y},{force.z}";
            Debug.Log($"GameClient - Sent: {text}");
            sw.WriteLine(text);
            sw.Flush();
            tempForce = Vector3.zero;
            tempForcePlayer = null;
            return;
        }
        catch (Exception ex)
        {
            //debug
            Debug.Log($"Something Error : {ex}");
        }

    }

    public void onMainMenu()
    {
        SceneManager.LoadScene("MainMenu");
    }
}
